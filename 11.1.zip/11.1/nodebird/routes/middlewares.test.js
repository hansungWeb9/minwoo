test('1 + 1은 2입니다.', () => {
  expect(1 + 1).toEqual(2);
});
